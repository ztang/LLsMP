#!/bin/bash

clear
echo "========================================================================="
echo "LLsMP V0.3 for CentOS/RedHat Linux Written by w0w.me"
echo "========================================================================="
echo "A tool to auto-compile & install Litespeed+MySQL+PHP on Linux "
echo ""
echo "For more information please visit http://llsmp.org/"
echo "========================================================================="

# Check if user is root
if [ $(id -u) != "0" ]; then
    echo "Error: You must be root to run this script, please use root to install llsmp"
    exit 1
fi

cd `dirname "$0"`
source ./functions.sh 2>/dev/null
if [ $? != 0 ]; then
    . ./functions.sh
    if [ $? != 0 ]; then
        echo [ERROR] Can not include 'functions.sh'.
        exit 1
    fi
fi

check_installed

if [ $INSATLL_TYPE="INSTALL" ]; then
choose_package
fi

if [ $package = "1" ]; then
init
sync_time
install_packages
install_litespeed
build_php
install_mysql
install_zend
phpinfo
phpmyadmin
default_conf
vhost
tool
restart_lsws
finish
installed_file
fi

if [ $package = "2" ]; then
custominit
init
sync_time
	
	if [ $mysql_i != "y" ]; then
	install_packages_without_mysql
		else
		install_packages
		install_mysql
	fi
	
	if [ $php_i != "y" ] ; then
	install_litespeed_without_php
		else
		install_litespeed
	fi
	
	if [ $php_i = "y" ] && [ $ea_i = "y" ] && [ $mysql_i = "y" ]; then
	build_php
	fi
	
	if [ $php_i = "y" ] && [ $ea_i = "y" ] && [ $mysql_i != "y" ]; then
	build_php_without_mysql
	fi
	
	if [ $php_i = "y" ] && [ $ea_i != "y" ] && [ $mysql_i = "y" ]; then
	build_php_without_ea
	fi
	
	if [ $php_i = "y" ] && [ $ea_i != "y" ] && [ $mysql_i != "y" ]; then
	build_php_without_ea_mysql
	fi
	
	if [ $zend_i = "y" ]; then
	install_zend
	fi
	
phpinfo
	
	if [ $phpmyadmin_i = "y" ]; then
	phpmyadmin
	fi
	
default_conf
vhost
tool
restart_lsws
finish
installed_file
fi
