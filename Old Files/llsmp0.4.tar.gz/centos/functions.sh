#!/bin/bash

check_installed()
{
if [ ! -f "/root/llsmp/.installed" ];then
INSATLL_TYPE="INSTALL"
else
echo "You have installed LLsMP already."
exit 1
fi
}

choose_package()
{
echo "Please choose which type of installation you want"
echo "[1]Full Installation"
echo "[2]Custom Installation"
printf "Please input the prefix number.(Default : 1)" 
read tmp_package
if [ $tmp_package = "" ]; then
tmp_package=1
fi
if [ $tmp_package = "2" ]; then
package="2"
echo "You have chosen Custom Installation"
echo "========================================================================="
else
package="1"
echo "You have chosen Full Installation"
echo "========================================================================="
fi
}

custominit()
{
echo "Custom Installation"
printf "Do you want to install MySQL?[y/n]" 
read mysql_i
echo ""
printf "Do you want to install PHP?[y/n]" 
read php_i
echo ""
if [ $mysql_i = "y" ] && [ $php_i = "y" ];then
printf "Do you want to install phpMyAdmin?[y/n]" 
read phpmyadmin_i
echo ""
fi
echo "========================================================================="
}


init()
{
#set up	email
email="root@localhost.com"
	echo "Please input email:"
	printf "(Default email: root@localhost.com):" 
	read email
	echo ""
	if [ "$email" = "" ]; then
		email="root@localhost.com"
	fi
	echo "========================================================================="
	echo email="$email"
	echo "========================================================================="
	
#set up	username
username="admin"
	echo "Please input username:"
	printf "(Default username: admin):" 
	read username
	echo ""
	if [ "$username" = "" ]; then
		username="admin"
	fi
	echo "========================================================================="
	echo username="$username"
	echo "========================================================================="

password_i="0"	
while [ $password_i != "1" ]
do	
#set up	password
password="admin123"
	echo "Please input Litespeed and MySQL password(AT LEAST 6 CHARACTERS!!!!!):"
	printf "(Default password: admin123):" 
	read password
	echo ""
	if [ "$password" = "" ]; then
		password="admin123"
	fi
	echo "========================================================================="
	echo password="$password"
	echo "========================================================================="
password_i="1"
#check length of password
string=${#password}
	if [ "$string" -lt "6" ]; then
		echo "AT LEAST 6 CHARACTERS!!!!PLEASE RUN THE SCRIPT AGAIN!!!"
		password_i="0"
	fi
done
}

sync_time()
{
#Synchronization time
rm -rf /etc/localtime
ln -s /usr/share/zoneinfo/Asia/Shanghai /etc/localtime

yum install -y ntp
ntpdate -d cn.pool.ntp.org
date
}

install_packages()
{
#Install packeages
rpm -qa|grep  httpd
rpm -e httpd
rpm -qa|grep mysql
rpm -e mysql
rpm -qa|grep php
rpm -e php
yum -y remove httpd
yum -y remove httpd*
yum -y remove mysql*
yum -y remove php*
yum -y install yum-fastestmirror
yum -y remove httpd
yum -y update
yum -y install gcc automake mhash-devel expect ruby autoconf libtool gcc-c++ libjpeg-devel libpng-devel libxml2-devel curl curl-devel libmcrypt-devel freetype-devel patch make mysql-server mysql-devel zlib-devel
}

install_packages_without_mysql()
{
#Install packeages
rpm -qa|grep  httpd
rpm -e httpd
rpm -qa|grep mysql
rpm -e mysql
rpm -qa|grep php
rpm -e php
yum -y remove httpd
yum -y remove httpd*
yum -y remove mysql*
yum -y remove php*
yum -y install yum-fastestmirror
yum -y remove httpd
yum -y update
yum -y install gcc automake mhash-devel expect ruby autoconf libtool gcc-c++ libjpeg-devel libpng-devel libxml2-devel curl curl-devel freetype-devel patch make libmcrypt-devel zlib-devel
}

install_litespeed()
{
#Download litespeed
mkdir /tmp/llsmp
cd /tmp/llsmp
wget http://llsmp.googlecode.com/files/lsws-4.0.18.tar.gz
tar zxvf lsws-4.0.18.tar.gz
cd lsws-4.0.18
chmod +x functions.sh

#Install Litespeed
expect -c "
spawn /tmp/llsmp/lsws-4.0.18/install.sh
expect \"5RetHEgU10\"
send \"\r\"
expect \"5RetHEgU11\"
send \"$username\r\"
expect \"5RetHEgU12\"
send \"$password\r\"
expect \"5RetHEgU13\"
send \"$password\r\"
expect \"5RetHEgU14\"
send \"$email\r\"
expect \"5RetHEgU1\"
send \"\r\"
expect \"5RetHEgU2\"
send \"\r\"
expect \"5RetHEgU3\"
send \"80\r\"
expect \"5RetHEgU4\"
send \"\r\"
expect \"5RetHEgU5\"
send \"Y\r\"
expect \"5RetHEgU6\"
send \"\r\"
expect \"5RetHEgU7\"
send \"N\r\"
expect \"5RetHEgU8\"
send \"Y\r\"
expect \"5RetHEgU9\"
send \"Y\r\"
"
}

install_litespeed_without_php()
{
#Download litespeed
mkdir /tmp/llsmp
cd /tmp/llsmp
wget http://llsmp.googlecode.com/files/lsws-4.0.18.tar.gz
tar zxvf lsws-4.0.18.tar.gz
cd lsws-4.0.18
chmod +x functions.sh

#Install Litespeed
expect -c "
spawn /tmp/llsmp/lsws-4.0.18/install.sh
expect \"5RetHEgU10\"
send \"\r\"
expect \"5RetHEgU11\"
send \"$username\r\"
expect \"5RetHEgU12\"
send \"$password\r\"
expect \"5RetHEgU13\"
send \"$password\r\"
expect \"5RetHEgU14\"
send \"$email\r\"
expect \"5RetHEgU1\"
send \"\r\"
expect \"5RetHEgU2\"
send \"\r\"
expect \"5RetHEgU3\"
send \"80\r\"
expect \"5RetHEgU4\"
send \"\r\"
expect \"5RetHEgU5\"
send \"N\r\"
expect \"5RetHEgU7\"
send \"N\r\"
expect \"5RetHEgU8\"
send \"Y\r\"
expect \"5RetHEgU9\"
send \"Y\r\"
"
}

build_php()
{
#Build PHP 
mkdir /usr/local/lsws/phpbuild
cd /tmp/llsmp
wget http://us.php.net/get/php-5.2.17.tar.gz/from/this/mirror -O php-5.2.17.tar.gz
wget http://www.litespeedtech.com/packages/lsapi/php-litespeed-5.5.tgz
wget http://files.directadmin.com/services/custombuild/php-5.2.17-mail-header.patch
tar zxvf php-5.2.17.tar.gz
tar zxvf php-litespeed-5.5.tgz
cd /tmp/llsmp/php-5.2.17
patch -p1 < /tmp/llsmp/php-5.2.17-mail-header.patch
mv /tmp/llsmp/litespeed /tmp/llsmp/php-5.2.17/sapi/litespeed/
cd /tmp/llsmp
mv php-5.2.17 /usr/local/lsws/phpbuild
cd /usr/local/lsws/phpbuild/php-5.2.17
touch ac*
rm -rf autom4te.*
./buildconf --force
./configure '--prefix=/usr/local/lsws/lsphp5' '--with-pdo-mysql' '--with-mysql' '--with-mysqli' '--with-zlib' '--with-gd' '--enable-shmop' '--enable-track-vars' '--enable-sockets' '--enable-sysvsem' '--enable-sysvshm' '--enable-magic-quotes' '--enable-mbstring' '--with-iconv' '--with-litespeed' '--enable-inline-optimization' '--with-curl' '--with-curlwrappers' '--with-mcrypt' '--with-mhash' '--with-mime-magic' '--with-openssl' '--with-freetype-dir=/usr/lib' '--with-jpeg-dir=/usr/lib'
make clean
echo `date`
make
make -k install
cd /usr/local/lsws/fcgi-bin
if [ -e "lsphp-5.2.17" ] ; then
	mv lsphp-5.2.17 lsphp-5.2.17.bak
fi
cp /usr/local/lsws/phpbuild/php-5.2.17/sapi/litespeed/php lsphp-5.2.17
ln -sf lsphp-5.2.17 lsphp5
chown -R lsadm:lsadm /usr/local/lsws/phpbuild/php-5.2.17
echo "[zend]" >>/usr/local/lsws/lsphp5/lib/php.ini
}


build_php_without_mysql()
{
#Build PHP 
mkdir /usr/local/lsws/phpbuild
cd /tmp/llsmp
wget http://us.php.net/get/php-5.2.17.tar.gz/from/this/mirror -O php-5.2.17.tar.gz
wget http://www.litespeedtech.com/packages/lsapi/php-litespeed-5.5.tgz
wget http://files.directadmin.com/services/custombuild/php-5.2.17-mail-header.patch
tar zxvf php-5.2.17.tar.gz
tar zxvf php-litespeed-5.5.tgz
cd /tmp/llsmp/php-5.2.17
patch -p1 < /tmp/llsmp/php-5.2.17-mail-header.patch
mv /tmp/llsmp/litespeed /tmp/llsmp/php-5.2.17/sapi/litespeed/
cd /tmp/llsmp
mv php-5.2.17 /usr/local/lsws/phpbuild
cd /usr/local/lsws/phpbuild/php-5.2.17
touch ac*
rm -rf autom4te.*
./buildconf --force
./configure '--prefix=/usr/local/lsws/lsphp5' '--with-zlib' '--with-gd' '--enable-shmop' '--enable-track-vars' '--enable-sockets' '--enable-sysvsem' '--enable-sysvshm' '--enable-magic-quotes' '--enable-mbstring' '--with-iconv' '--with-litespeed' '--enable-inline-optimization' '--with-curl' '--with-curlwrappers' '--with-mcrypt' '--with-mhash' '--with-mime-magic' '--with-openssl' '--with-freetype-dir=/usr/lib' '--with-jpeg-dir=/usr/lib'
make clean
echo `date`
make
make -k install
cd /usr/local/lsws/fcgi-bin
if [ -e "lsphp-5.2.17" ] ; then
	mv lsphp-5.2.17 lsphp-5.2.17.bak
fi
cp /usr/local/lsws/phpbuild/php-5.2.17/sapi/litespeed/php lsphp-5.2.17
ln -sf lsphp-5.2.17 lsphp5
chown -R lsadm:lsadm /usr/local/lsws/phpbuild/php-5.2.17
echo "[zend]" >>/usr/local/lsws/lsphp5/lib/php.ini
}

install_mysql()
{
#Mysql Setting
service mysqld start
mysqladmin -u root password $password
sed -i '/\[mysqld\]/a\skip-locking\nskip-bdb\nskip-innodb' /etc/my.cnf
service mysqld restart
chkconfig --level 345 mysqld on
}

phpinfo()
{
#Download phpinfo
cd /tmp/llsmp
wget http://llsmp.googlecode.com/files/d_files.tar.gz
tar zxvf d_files.tar.gz
rm -rf /usr/local/lsws/DEFAULT/html/*
mv -f d_files/* /usr/local/lsws/DEFAULT/html/
}

phpmyadmin()
{
#Download phpmyadmin
cd /tmp/llsmp
wget http://downloads.sourceforge.net/project/phpmyadmin/phpMyAdmin/3.3.9/phpMyAdmin-3.3.9-all-languages.tar.gz
tar zxvf phpMyAdmin-3.3.9-all-languages.tar.gz
mkdir /usr/local/lsws/DEFAULT/html/phpmyadmin
mv -f phpMyAdmin-3.3.9-all-languages/* /usr/local/lsws/DEFAULT/html/phpmyadmin
}

default_conf()
{
#Set conf
cd /tmp/llsmp
wget http://llsmp.googlecode.com/files/conf.tar.gz
tar zxvf conf.tar.gz
rm -f /usr/local/lsws/DEFAULT/conf/*
mv conf/* /usr/local/lsws/DEFAULT/conf/
}

#Restart Litespeed
restart_lsws(){
service lsws restart
}

finish()
{
echo "========================================================================="
echo "LLsMP has been set up."
echo "Please configure in the Litespeed control panel : http://<your_ip>:7080"
echo "========================================================================="
echo "For more information please visit http://llsmp.org/"
echo "========================================================================="
echo "BYE~"
}

installed_file()
{
echo "LLsMP 0.4 CentOS" >> /root/llsmp/.installed
}