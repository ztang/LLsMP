#!/bin/bash

clear
echo "========================================================================="
echo "ionCube Installation for LLsMP 0.4 Written by w0w.me"
echo "========================================================================="
echo "LLsMP is A tool to auto-compile & install Litespeed+MySQL+PHP on Linux "
echo ""
echo "For more information please visit http://llsmp.org/"
echo "========================================================================="
echo ""
echo "========================================================================="
echo "Installing..."
echo "========================================================================="
mkdir /tmp/llsmp
cd /tmp/llsmp
wget -c http://downloads2.ioncube.com/loader_downloads/ioncube_loaders_lin_x86.tar.gz
tar zxvf ioncube_loaders_lin_x86.tar.gz
mv ioncube/ioncube_loader_lin_5.2.so /usr/local/lsws/lsphp5/lib/php/extensions/no-debug-non-zts-20060613/ioncube_loader_lin_5.2.so
sed -i '/\[zend\]/i\\n\[ionCube\]\nzend_extension="/usr/local/lsws/lsphp5/lib/php/extensions/no-debug-non-zts-20060613/ioncube_loader_lin_5.2.so"\n' /usr/local/lsws/lsphp5/lib/php.ini
/etc/init.d/lsws restart
echo "========================================================================="
echo "Done"
echo "========================================================================="