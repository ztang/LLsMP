#!/bin/bash

clear
echo "========================================================================="
echo "ionCube Installation for LLsMP 0.4 Written by w0w.me"
echo "========================================================================="
echo "LLsMP is A tool to auto-compile & install Litespeed+MySQL+PHP on Linux "
echo ""
echo "For more information please visit http://llsmp.org/"
echo "========================================================================="
echo ""
echo "========================================================================="
echo "Installing..."
echo "========================================================================="
mkdir /tmp/llsmp
cd /tmp/llsmp
wget http://downloads.zend.com/optimizer/3.3.9/ZendOptimizer-3.3.9-linux-glibc23-i386.tar.gz
tar xvf ZendOptimizer-3.3.9-linux-glibc23-i386.tar.gz
cp -f ZendOptimizer-3.3.9-linux-glibc23-i386/data/5_2_x_comp/ZendOptimizer.so /usr/local/lsws/lsphp5/lib/php/extensions/no-debug-non-zts-20060613/
sed -i '/\[zend\]/a\\zend_optimizer.optimization_level=1\nzend_extension="/usr/local/lsws/lsphp5/lib/php/extensions/no-debug-non-zts-20060613/ZendOptimizer.so"\n' /usr/local/lsws/lsphp5/lib/php.ini
/etc/init.d/lsws restart
echo "========================================================================="
echo "Done"
echo "========================================================================="