#!/bin/bash

check_installed()
{
if [ ! -f "/root/llsmp/.installed" ];then
INSATLL_TYPE="INSTALL"
else
echo "You have installed LLsMP already."
exit 1
fi
}

choose_package()
{
echo "Please choose which type of installation you want"
echo "[1]Full Installation"
echo "[2]Custom Installation"
read -p "Please input the prefix number.(Default : 1)" tmp_package
if [ $tmp_package = "2" ]; then
package="2"
echo "You have chosen Custom Installation"
echo "========================================================================="
else
package="1"
echo "You have chosen Full Installation"
echo "========================================================================="
fi
}

custominit()
{
echo "Custom Installation"
read -p "Do you want to install MySQL?[y/n]" mysql_i
read -p "Do you want to install PHP?[y/n]" php_i
if [ $mysql_i = "y" ] && [ $php_i = "y" ];then
read -p "Do you want to install phpMyAdmin?[y/n]" phpmyadmin_i
fi
if [ $php_i = "y" ];then
read -p "Do you want to install Zend Optimizer?[y/n]" zend_i
read -p "Do you want to install eAccelerator?[y/n]" ea_i
fi
echo "========================================================================="
}


init()
{
#set up	email
email="root@localhost.com"
	echo "Please input email:"
	read -p "(Default email: root@localhost.com):" email
	if [ "$email" = "" ]; then
		email="root@localhost.com"
	fi
	echo "========================================================================="
	echo email="$email"
	echo "========================================================================="
	
#set up	username
username="admin"
	echo "Please input username:"
	read -p "(Default username: admin):" username
	if [ "$username" = "" ]; then
		username="admin"
	fi
	echo "========================================================================="
	echo username="$username"
	echo "========================================================================="
	
#set up	password
password="admin123"
	echo "Please input Litespeed and MySQL password(AT LEAST 6 CHARACTERS!!!!!):"
	read -p "(Default password: admin123):" password
	if [ "$password" = "" ]; then
		password="admin123"
	fi
	echo "========================================================================="
	echo password="$password"
	echo "========================================================================="
#check length of password
string=${#password}
	if [ "$string" -lt "6" ]; then
		echo "AT LEAST 6 CHARACTERS!!!!PLEASE RUN THE SCRIPT AGAIN!!!"
		exit 1 
	fi
}

sync_time()
{
#Synchronization time
rm -rf /etc/localtime
ln -s /usr/share/zoneinfo/Asia/Shanghai /etc/localtime
apt-get update
apt-get install -y --force-yes ntp chkconfig
ntpdate -d cn.pool.ntp.org
date
}

install_packages()
{
#Install packeages
apt-get update
apt-get remove -y --force-yes -q apache* 
apt-get remove -y --force-yes -q mysql* 
apt-get remove -y --force-yes -q php*
apt-get remove -y --force-yes -q autoconf*
export DEBIAN_FRONTEND=noninteractive
apt-get install -y --force-yes -q expect libmysql++-dev autoconf2.13 gcc g++ libjpeg62-dev libpng12-dev libxml2-dev curl libcurl4-openssl-dev libmcrypt-dev libmhash-dev libfreetype6-dev patch make mcrypt mysql-server libmysql++-dev zlib-bin zlib1g-dev
export PHP_autoconf=/usr/bin/autoconf2.13
export PHP_AUTOHEADER=/usr/bin/autoheader2.13
}

install_packages_without_mysql()
{
apt-get update
apt-get remove -y --force-yes -q apache* 
apt-get remove -y --force-yes -q mysql* 
apt-get remove -y --force-yes -q php*
apt-get remove -y --force-yes -q autoconf*
export DEBIAN_FRONTEND=noninteractive
apt-get install -y --force-yes -q expect autoconf2.13 gcc g++ libjpeg62-dev libpng12-dev libxml2-dev curl libcurl4-openssl-dev libmcrypt-dev libmhash-dev libfreetype6-dev patch make mcrypt libmysql++-dev zlib-bin zlib1g-dev
export PHP_autoconf=/usr/bin/autoconf2.13
export PHP_AUTOHEADER=/usr/bin/autoheader2.13
}

install_litespeed()
{
#Download litespeed
mkdir /tmp/llsmp
cd /tmp/llsmp
wget http://llsmp.googlecode.com/files/lsws-4.0.18.tar.gz
tar zxvf lsws-4.0.18.tar.gz
cd lsws-4.0.18
chmod +x functions.sh

#Install Litespeed
expect -c "
spawn /tmp/llsmp/lsws-4.0.18/install.sh
expect \"5RetHEgU10\"
send \"\r\"
expect \"5RetHEgU11\"
send \"$username\r\"
expect \"5RetHEgU12\"
send \"$password\r\"
expect \"5RetHEgU13\"
send \"$password\r\"
expect \"5RetHEgU14\"
send \"$email\r\"
expect \"5RetHEgU1\"
send \"\r\"
expect \"5RetHEgU2\"
send \"\r\"
expect \"5RetHEgU3\"
send \"80\r\"
expect \"5RetHEgU4\"
send \"\r\"
expect \"5RetHEgU5\"
send \"Y\r\"
expect \"5RetHEgU6\"
send \"\r\"
expect \"5RetHEgU7\"
send \"N\r\"
expect \"5RetHEgU8\"
send \"Y\r\"
expect \"5RetHEgU9\"
send \"Y\r\"
"
}

install_litespeed_without_php()
{
#Download litespeed
mkdir /tmp/llsmp
cd /tmp/llsmp
wget http://llsmp.googlecode.com/files/lsws-4.0.18.tar.gz
tar zxvf lsws-4.0.18.tar.gz
cd lsws-4.0.18
chmod +x functions.sh

#Install Litespeed
expect -c "
spawn /tmp/llsmp/lsws-4.0.18/install.sh
expect \"5RetHEgU10\"
send \"\r\"
expect \"5RetHEgU11\"
send \"$username\r\"
expect \"5RetHEgU12\"
send \"$password\r\"
expect \"5RetHEgU13\"
send \"$password\r\"
expect \"5RetHEgU14\"
send \"$email\r\"
expect \"5RetHEgU1\"
send \"\r\"
expect \"5RetHEgU2\"
send \"\r\"
expect \"5RetHEgU3\"
send \"80\r\"
expect \"5RetHEgU4\"
send \"\r\"
expect \"5RetHEgU5\"
send \"N\r\"
expect \"5RetHEgU7\"
send \"N\r\"
expect \"5RetHEgU8\"
send \"Y\r\"
expect \"5RetHEgU9\"
send \"Y\r\"
"
}

build_php()
{
#Build PHP 
cd /tmp/llsmp
wget http://llsmp.googlecode.com/files/phpbuildv0.2Beta.tar.gz
tar zxvf phpbuildv0.2Beta.tar.gz
mv -f phpbuild/* /usr/local/lsws/phpbuild
mkdir /tmp/eaccelerator
chmod 777 /tmp/eaccelerator
/usr/local/lsws/phpbuild/buildphp_manual_run.sh
echo ';	 =================' >> /usr/local/lsws/lsphp5/lib/php.ini
echo ';	 eAccelerator' >> /usr/local/lsws/lsphp5/lib/php.ini
echo ';	 =================' >> /usr/local/lsws/lsphp5/lib/php.ini
echo 'extension="eaccelerator.so"' >> /usr/local/lsws/lsphp5/lib/php.ini
echo 'eaccelerator.shm_size= 16' >> /usr/local/lsws/lsphp5/lib/php.ini
echo 'eaccelerator.cache_dir="/tmp/eaccelerator"' >> /usr/local/lsws/lsphp5/lib/php.ini
echo 'eaccelerator.enable=1' >> /usr/local/lsws/lsphp5/lib/php.ini
echo 'eaccelerator.optimizer=1' >> /usr/local/lsws/lsphp5/lib/php.ini
echo 'eaccelerator.check_mtime=1' >> /usr/local/lsws/lsphp5/lib/php.ini
echo 'eaccelerator.debug=0' >> /usr/local/lsws/lsphp5/lib/php.ini
echo 'eaccelerator.filter=""' >> /usr/local/lsws/lsphp5/lib/php.ini
echo 'eaccelerator.shm_max="0"' >> /usr/local/lsws/lsphp5/lib/php.ini
echo 'eaccelerator.shm_ttl="0"' >> /usr/local/lsws/lsphp5/lib/php.ini
echo 'eaccelerator.shm_prune_period="0"' >> /usr/local/lsws/lsphp5/lib/php.ini
echo 'eaccelerator.shm_only="0"' >> /usr/local/lsws/lsphp5/lib/php.ini
echo 'eaccelerator.compress="1"' >> /usr/local/lsws/lsphp5/lib/php.ini
echo 'eaccelerator.compress_level="9"' >> /usr/local/lsws/lsphp5/lib/php.ini
}

build_php_without_ea()
{
#Build PHP 
cd /tmp/llsmp
wget http://llsmp.googlecode.com/files/phpbuild_without_ea.tar.gz
tar zxvf phpbuild_without_ea.tar.gz
mv -f phpbuild/* /usr/local/lsws/phpbuild
/usr/local/lsws/phpbuild/buildphp_manual_run.sh
}

build_php_without_mysql()
{
#Build PHP 
cd /tmp/llsmp
wget http://llsmp.googlecode.com/files/phpbuild_without_mysql.tar.gz
tar zxvf phpbuild_without_mysql.tar.gz
mv -f phpbuild/* /usr/local/lsws/phpbuild
/usr/local/lsws/phpbuild/buildphp_manual_run.sh
mkdir /tmp/eaccelerator
chmod 777 /tmp/eaccelerator
echo ';	 =================' >> /usr/local/lsws/lsphp5/lib/php.ini
echo ';	 eAccelerator' >> /usr/local/lsws/lsphp5/lib/php.ini
echo ';	 =================' >> /usr/local/lsws/lsphp5/lib/php.ini
echo 'extension="eaccelerator.so"' >> /usr/local/lsws/lsphp5/lib/php.ini
echo 'eaccelerator.shm_size= 16' >> /usr/local/lsws/lsphp5/lib/php.ini
echo 'eaccelerator.cache_dir="/tmp/eaccelerator"' >> /usr/local/lsws/lsphp5/lib/php.ini
echo 'eaccelerator.enable=1' >> /usr/local/lsws/lsphp5/lib/php.ini
echo 'eaccelerator.optimizer=1' >> /usr/local/lsws/lsphp5/lib/php.ini
echo 'eaccelerator.check_mtime=1' >> /usr/local/lsws/lsphp5/lib/php.ini
echo 'eaccelerator.debug=0' >> /usr/local/lsws/lsphp5/lib/php.ini
echo 'eaccelerator.filter=""' >> /usr/local/lsws/lsphp5/lib/php.ini
echo 'eaccelerator.shm_max="0"' >> /usr/local/lsws/lsphp5/lib/php.ini
echo 'eaccelerator.shm_ttl="0"' >> /usr/local/lsws/lsphp5/lib/php.ini
echo 'eaccelerator.shm_prune_period="0"' >> /usr/local/lsws/lsphp5/lib/php.ini
echo 'eaccelerator.shm_only="0"' >> /usr/local/lsws/lsphp5/lib/php.ini
echo 'eaccelerator.compress="1"' >> /usr/local/lsws/lsphp5/lib/php.ini
echo 'eaccelerator.compress_level="9"' >> /usr/local/lsws/lsphp5/lib/php.ini
}


build_php_without_ea_mysql()
{
#Build PHP 
cd /tmp/llsmp
wget http://llsmp.googlecode.com/files/phpbuild_without_ea_mysql.tar.gz
tar zxvf phpbuild_without_ea_mysql.tar.gz
mv -f phpbuild/* /usr/local/lsws/phpbuild
/usr/local/lsws/phpbuild/buildphp_manual_run.sh
}


install_mysql()
{
#Mysql Setting
service mysql start
mysqladmin -u root password $password
sed -i '/\[mysqld\]/a\skip-locking\nskip-bdb\nskip-innodb' /etc/mysql/my.cnf
service mysql restart
update-rc.d mysql defaults
}

install_zend()
{
#Install Zend Optimizer
cd /tmp/llsmp
wget http://downloads.zend.com/optimizer/3.3.9/ZendOptimizer-3.3.9-linux-glibc23-i386.tar.gz
tar xvf ZendOptimizer-3.3.9-linux-glibc23-i386.tar.gz
cp -f ZendOptimizer-3.3.9-linux-glibc23-i386/data/5_2_x_comp/ZendOptimizer.so /usr/local/lsws/lsphp5/lib/php/extensions/no-debug-non-zts-20060613/
echo '[Zend Optimizer]' >> /usr/local/lsws/lsphp5/lib/php.ini
echo 'zend_optimizer.optimization_level=1' >> /usr/local/lsws/lsphp5/lib/php.ini
echo 'zend_extension="/usr/local/lsws/lsphp5/lib/php/extensions/no-debug-non-zts-20060613/ZendOptimizer.so"' >> /usr/local/lsws/lsphp5/lib/php.ini
}

phpinfo()
{
#Download phpinfo
cd /tmp/llsmp
wget http://llsmp.googlecode.com/files/phpinfo.tar.gz
tar zxvf phpinfo.tar.gz
rm -f /usr/local/lsws/DEFAULT/html/phpinfo.php
mv -f phpinfo.php /usr/local/lsws/DEFAULT/html/
}

phpmyadmin()
{
#Download phpmyadmin
cd /tmp/llsmp
wget http://downloads.sourceforge.net/project/phpmyadmin/phpMyAdmin/3.3.9/phpMyAdmin-3.3.9-all-languages.tar.gz
tar zxvf phpMyAdmin-3.3.9-all-languages.tar.gz
mkdir /usr/local/lsws/DEFAULT/html/phpmyadmin
mv -f phpMyAdmin-3.3.9-all-languages/* /usr/local/lsws/DEFAULT/html/phpmyadmin
}

default_conf()
{
#Set conf
cd /tmp/llsmp
wget http://llsmp.googlecode.com/files/conf.tar.gz
tar zxvf conf.tar.gz
rm -f /usr/local/lsws/DEFAULT/conf/*
mv conf/* /usr/local/lsws/DEFAULT/conf/
}

vhost()
{
#Virtual Dir
mkdir /usr/local/lsws/wwwroot
chown -R lsadm:lsadm /usr/local/lsws/wwwroot
}

tool()
{
#tool
cd /tmp/llsmp
wget http://llsmp.googlecode.com/files/debiantool.tar.gz
tar zxvf debiantool.tar.gz
mkdir /root/llsmp
mv -f vhost.sh /root/llsmp
mv -f vsftpd.sh /root/llsmp
}

#Restart Litespeed
restart_lsws()
{
service lsws restart
}

finish()
{
echo "========================================================================="
echo "LLsMP has been set up."
echo "Please configure in the Litespeed control panel : http://<your_ip>:7080"
echo "========================================================================="
echo "For more information please visit http://llsmp.org/"
echo "========================================================================="
echo "BYE~"
}

installed_file()
{
echo "LLsMP 0.3.2 Ubuntu" >> /root/llsmp/.installed
}