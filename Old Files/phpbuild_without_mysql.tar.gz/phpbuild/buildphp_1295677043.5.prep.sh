#!/bin/sh

###########################################
#	EXTRA_PATH_ENV = 
#	PROGRESS_F = /usr/local/lsws/phpbuild/buildphp_1295677043.5.progress
###########################################

PATH=$PATH

check_errs()
{
  if [ "${1}" -ne "0" ] ; then
    echo "**ERROR** ${2}"
    echo "**ERROR** ${2}" >> /usr/local/lsws/phpbuild/buildphp_1295677043.5.progress
    exit ${1}
  fi
}

main_msg()
{
	# write to both stdout and progress
	echo "${1}"
	echo "${1}" >> /usr/local/lsws/phpbuild/buildphp_1295677043.5.progress
}

# clear out
echo "**MAIN_STATUS** retrieved from /usr/local/lsws/phpbuild/buildphp_1295677043.5.progress" > /usr/local/lsws/phpbuild/buildphp_1295677043.5.progress

###########################################
#	PHP_VERSION = 5.2.16
#	PHP_BUILD_DIR = /usr/local/lsws/phpbuild
#	DL_METHOD = curl -L -o
#	ENABLE_SUHOSIN = 0 # 1 or 0
#	SUHOSIN_PATCH_URL = http://download.suhosin.org/suhosin-patch-5.2.16-0.9.7.patch.gz
#	ENABLE_MAILHEADER = 1 # 1 or 0
#	LSAPI_VERSION = 5.5
###########################################

echo "============================================================="
main_msg "Preparing all source code for building PHP 5.2.16 with LSAPI"
echo "============================================================="
echo `date`
echo ""

echo "Changing to build directory /usr/local/lsws/phpbuild" 
cd /usr/local/lsws/phpbuild
check_errs $? "Could not get into build directory"

if [ -e "php-5.2.16" ] ; then
	rm -rf php-5.2.16
	check_errs $? "Could not delete old php directory /usr/local/lsws/phpbuild/php-5.2.16"
fi

test_phpsrc_ok()
{
	main_msg "Extracting PHP source archive: tar -zxf ${1}" 
	tar -zxf ${1}
	if [ "$?" -ne "0" ] ; then
		## remove bad copy
		rm -f ${1}
		main_msg "Could not extract PHP source archive"
		return 1
	fi
	return 0
}


PHP_SRC=php-5.2.16.tar.gz
PHP_SRC_READY=N

if [ -e "$PHP_SRC" ] ; then
	main_msg "$PHP_SRC already downloaded, use the saved copy."
	test_phpsrc_ok $PHP_SRC
	if [ "$?" -eq "0" ] ; then
		PHP_SRC_READY=Y
	fi
fi

if [ $PHP_SRC_READY = "N" ] ; then
	DOWNLOAD_URL="http://us.php.net/get/$PHP_SRC/from/us.php.net/mirror"
	main_msg "Retrieving PHP source archive from $DOWNLOAD_URL" 
	curl -L -o $PHP_SRC $DOWNLOAD_URL

	test_phpsrc_ok $PHP_SRC
	if [ "$?" -eq "0" ] ; then
		PHP_SRC_READY=Y
	fi
fi

if [ $PHP_SRC_READY = "N" ] ; then
	MAIN_VER=`expr '5.2.16' : "\(.\)"`
	DOWNLOAD_URL="http://museum.php.net/php$MAIN_VER/$PHP_SRC"
	main_msg "Try again, retrieving PHP source archive from $DOWNLOAD_URL" 
	curl -L -o $PHP_SRC $DOWNLOAD_URL

	test_phpsrc_ok $PHP_SRC
	if [ "$?" -eq "0" ] ; then
		PHP_SRC_READY=Y
	fi
fi

if [ $PHP_SRC_READY = "N" ] ; then
	check_errs $? "Fail to retrieve PHP source archive. Please try manually download."
fi
	
echo ""

if [ 0 -eq 1 ] ; then

	if [ -e suhosin-patch-5.2.16.patch.gz ] ; then
		rm -f suhosin-patch-5.2.16.patch.gz
		check_errs $? "Could not delete old copy suhosin-patch-5.2.16.patch.gz"
	fi
	
	echo "Suhosin is enabled"
	main_msg "Retrieving Suhosin patch from http://download.suhosin.org/suhosin-patch-5.2.16-0.9.7.patch.gz" 
	curl -L -o suhosin-patch-5.2.16.patch.gz http://download.suhosin.org/suhosin-patch-5.2.16-0.9.7.patch.gz
	check_errs $? "Could not retrieve Suhosin patch"
	echo ""
	
	echo "Extracting Suhosin patch: gunzip -f suhosin-patch-5.2.16.patch.gz"
	gunzip -f suhosin-patch-5.2.16.patch.gz
	check_errs $? "Could not extract Suhosin patch"
	echo ""
	
	main_msg "Patching source with Suhosin patch" 
	cd php-5.2.16
	patch -p1 < ../suhosin-patch-5.2.16.patch
	check_errs $? "Could not patch source with Suhosin patch"
	cd ..
	echo ""
fi

if [ 1 -eq 1 ] ; then

	if [ -e php-5.2.16-mail-header.patch ] ; then
		rm -f php-5.2.16-mail-header.patch
		check_errs $? "Could not delete old copy php-5.2.16-mail-header.patch"
	fi

	DOWNLOAD_URL="http://files.directadmin.com/services/custombuild/php-5.2.16-mail-header.patch"
	main_msg "Retrieving mail header patch from $DOWNLOAD_URL"
	curl -L -o php-5.2.16-mail-header.patch $DOWNLOAD_URL
	check_errs $? "Could not retrieve mail header patch"
	echo ""
	
	main_msg "Patching source with mail header patch"
	cd php-5.2.16
	patch -p1 < ../php-5.2.16-mail-header.patch
	check_errs $? "Could not patch source with mail header patch"
	cd ..
	echo ""
fi

# get LSAPI

if [ -e php-litespeed-5.5.tgz ] ; then
	rm -f php-litespeed-5.5.tgz
	check_errs $? "Could not delete old lsapi copy php-litespeed-5.5.tgz"
fi

DOWNLOAD_URL="http://www.litespeedtech.com/packages/lsapi/php-litespeed-5.5.tgz"
main_msg "Retrieving LSAPI from $DOWNLOAD_URL"
curl -L -o "php-litespeed-5.5.tgz" $DOWNLOAD_URL
check_errs $? "Could not retrieve LSAPI archive"

cd php-5.2.16/sapi
check_errs $? "Could not get into php/sapi directory"

main_msg "Extracting LSAPI archive: tar -xzf php-litespeed-5.5.tgz" 
tar -xzf "../../php-litespeed-5.5.tgz"
check_errs $? "Could not extract LSAPI archive"
echo ""

echo "============================================================="
main_msg "Finished gathering all source code for building PHP 5.2.16"
echo "============================================================="
echo `date`
echo ""
###########################################
#	EXTENSION_NAME = eAccelerator
#	EXTENSION_SRC = eaccelerator-0.9.6.1.tar.bz2
#	EXTRACT_METHOD = tar -jxf
#	EXTENSION_DIR = eaccelerator-0.9.6.1
#	EXTENSION_DOWNLOAD_URL = http://bart.eaccelerator.net/source/0.9.6.1/eaccelerator-0.9.6.1.tar.bz2
###########################################

echo "============================================================="
main_msg "Preparing source code for building eAccelerator Extension"
echo "============================================================="
echo ""

echo "Changing to build directory /usr/local/lsws/phpbuild" 
cd /usr/local/lsws/phpbuild
check_errs $? "Could not get into build directory"

if [ -e "eaccelerator-0.9.6.1.tar.bz2" ] ; then
	main_msg "eaccelerator-0.9.6.1.tar.bz2 already downloaded, use the saved copy."
	NEW_DOWNLOAD=N
else
	main_msg "Retrieving eAccelerator extension source archive http://bart.eaccelerator.net/source/0.9.6.1/eaccelerator-0.9.6.1.tar.bz2" 
	curl -L -o eaccelerator-0.9.6.1.tar.bz2 http://bart.eaccelerator.net/source/0.9.6.1/eaccelerator-0.9.6.1.tar.bz2
	check_errs $? "Fail to retrieve eAccelerator extension source archive"
	echo ""
	NEW_DOWNLOAD=Y
fi

echo "Changing to build directory php-5.2.16" 
cd php-5.2.16
check_errs $? "Could not get into build directory"

echo "Copying eAccelerator extension source archive" 
cp ../eaccelerator-0.9.6.1.tar.bz2 .
check_errs $? "Could not copy"

main_msg "Extracting eAccelerator extension source archive: tar -jxf eaccelerator-0.9.6.1.tar.bz2" 
tar -jxf eaccelerator-0.9.6.1.tar.bz2

if [ "$?" -ne "0" ] ; then
	# remove bad copy
	rm -f eaccelerator-0.9.6.1.tar.bz2 ../eaccelerator-0.9.6.1.tar.bz2
	check_errs $? "Fail to remove bad copy eaccelerator-0.9.6.1.tar.bz2"

	if [ $NEW_DOWNLOAD = "Y" ] ; then
		check_errs 1 "Could not extract eAccelerator extension source archive"
	else
		main_msg "Failed to extract existing copy. try download again."
	
		main_msg "Retrieving eAccelerator extension source archive http://bart.eaccelerator.net/source/0.9.6.1/eaccelerator-0.9.6.1.tar.bz2" 
		curl -L -o ../eaccelerator-0.9.6.1.tar.bz2 http://bart.eaccelerator.net/source/0.9.6.1/eaccelerator-0.9.6.1.tar.bz2
		check_errs $? "Fail to retrieve eAccelerator extension source archive"
		NEW_DOWNLOAD=Y
	
		cp ../eaccelerator-0.9.6.1.tar.bz2 .
		check_errs $? "Could not copy"
	
		main_msg "Extracting eAccelerator extension source archive: tar -jxf eaccelerator-0.9.6.1.tar.bz2" 
		tar -jxf eaccelerator-0.9.6.1.tar.bz2
		
		if [ "$?" -ne "0" ] ; then
			# remove bad copy
			rm -f eaccelerator-0.9.6.1.tar.bz2 ../eaccelerator-0.9.6.1.tar.bz2
			check_errs $? "Fail to remove bad copy eaccelerator-0.9.6.1.tar.bz2"

			check_errs 1 "Could not extract eAccelerator extension source archive"
		fi
		
		if [ "eAccelerator" = "eAccelerator" ] ; then
			echo "  .. Special handling for eAccelerator: do not use spin lock, buggy"
			echo "     set mm_sem_spinlock=no and mm_sem_ipc=no in config.m4"
			cd eaccelerator-0.9.6.1
			cp config.m4 config.m4.orig
		    sed -e 's/mm_sem_spinlock=yes/mm_sem_spinlock=no/' -e 's/mm_sem_ipc=yes/mm_sem_ipc=no/' config.m4.orig > config.m4
			if [ "$?" -ne "0" ] ; then
				echo "   sed command error, please try to modify config.m4 manually to avoid using spinlock"
				# continue, do not abort here
			fi
		fi
	fi
else
	if [ "eAccelerator" = "eAccelerator" ] ; then
		echo "  .. Special handling for eAccelerator: do not use spin lock, buggy"
		echo "     set mm_sem_spinlock=no and mm_sem_ipc=no in config.m4"
		cd eaccelerator-0.9.6.1
		cp config.m4 config.m4.orig
	    sed -e 's/mm_sem_spinlock=yes/mm_sem_spinlock=no/' -e 's/mm_sem_ipc=yes/mm_sem_ipc=no/' config.m4.orig > config.m4
		if [ "$?" -ne "0" ] ; then
			echo "   sed command error, please try to modify config.m4 manually to avoid using spinlock"
			# continue, do not abort here
		fi
	fi
	
fi


echo "============================================================="
main_msg "Finished gathering source code for building eAccelerator extension"
echo "============================================================="
###########################################
#	EXTENSION_NAME = MemCache
#	EXTENSION_SRC = memcache-2.2.6.tgz
#	EXTRACT_METHOD = tar -zxf
#	EXTENSION_DIR = memcache-2.2.6
#	EXTENSION_DOWNLOAD_URL = http://pecl.php.net/get/memcache-2.2.6.tgz
###########################################

echo "============================================================="
main_msg "Preparing source code for building MemCache Extension"
echo "============================================================="
echo ""

echo "Changing to build directory /usr/local/lsws/phpbuild" 
cd /usr/local/lsws/phpbuild
check_errs $? "Could not get into build directory"

if [ -e "memcache-2.2.6.tgz" ] ; then
	main_msg "memcache-2.2.6.tgz already downloaded, use the saved copy."
	NEW_DOWNLOAD=N
else
	main_msg "Retrieving MemCache extension source archive http://pecl.php.net/get/memcache-2.2.6.tgz" 
	curl -L -o memcache-2.2.6.tgz http://pecl.php.net/get/memcache-2.2.6.tgz
	check_errs $? "Fail to retrieve MemCache extension source archive"
	echo ""
	NEW_DOWNLOAD=Y
fi

echo "Changing to build directory php-5.2.16" 
cd php-5.2.16
check_errs $? "Could not get into build directory"

echo "Copying MemCache extension source archive" 
cp ../memcache-2.2.6.tgz .
check_errs $? "Could not copy"

main_msg "Extracting MemCache extension source archive: tar -zxf memcache-2.2.6.tgz" 
tar -zxf memcache-2.2.6.tgz

if [ "$?" -ne "0" ] ; then
	# remove bad copy
	rm -f memcache-2.2.6.tgz ../memcache-2.2.6.tgz
	check_errs $? "Fail to remove bad copy memcache-2.2.6.tgz"

	if [ $NEW_DOWNLOAD = "Y" ] ; then
		check_errs 1 "Could not extract MemCache extension source archive"
	else
		main_msg "Failed to extract existing copy. try download again."
	
		main_msg "Retrieving MemCache extension source archive http://pecl.php.net/get/memcache-2.2.6.tgz" 
		curl -L -o ../memcache-2.2.6.tgz http://pecl.php.net/get/memcache-2.2.6.tgz
		check_errs $? "Fail to retrieve MemCache extension source archive"
		NEW_DOWNLOAD=Y
	
		cp ../memcache-2.2.6.tgz .
		check_errs $? "Could not copy"
	
		main_msg "Extracting MemCache extension source archive: tar -zxf memcache-2.2.6.tgz" 
		tar -zxf memcache-2.2.6.tgz
		
		if [ "$?" -ne "0" ] ; then
			# remove bad copy
			rm -f memcache-2.2.6.tgz ../memcache-2.2.6.tgz
			check_errs $? "Fail to remove bad copy memcache-2.2.6.tgz"

			check_errs 1 "Could not extract MemCache extension source archive"
		fi
		
		if [ "MemCache" = "eAccelerator" ] ; then
			echo "  .. Special handling for eAccelerator: do not use spin lock, buggy"
			echo "     set mm_sem_spinlock=no and mm_sem_ipc=no in config.m4"
			cd memcache-2.2.6
			cp config.m4 config.m4.orig
		    sed -e 's/mm_sem_spinlock=yes/mm_sem_spinlock=no/' -e 's/mm_sem_ipc=yes/mm_sem_ipc=no/' config.m4.orig > config.m4
			if [ "$?" -ne "0" ] ; then
				echo "   sed command error, please try to modify config.m4 manually to avoid using spinlock"
				# continue, do not abort here
			fi
		fi
	fi
else
	if [ "MemCache" = "eAccelerator" ] ; then
		echo "  .. Special handling for eAccelerator: do not use spin lock, buggy"
		echo "     set mm_sem_spinlock=no and mm_sem_ipc=no in config.m4"
		cd memcache-2.2.6
		cp config.m4 config.m4.orig
	    sed -e 's/mm_sem_spinlock=yes/mm_sem_spinlock=no/' -e 's/mm_sem_ipc=yes/mm_sem_ipc=no/' config.m4.orig > config.m4
		if [ "$?" -ne "0" ] ; then
			echo "   sed command error, please try to modify config.m4 manually to avoid using spinlock"
			# continue, do not abort here
		fi
	fi
	
fi


echo "============================================================="
main_msg "Finished gathering source code for building MemCache extension"
echo "============================================================="
main_msg "**PREPARE_DONE**"
