#!/bin/bash
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH

# Check if user is root
if \[ $(id -u) != "0" \]; then
    echo "Error: You must be root to run this script, please use root to install lnmp"
    exit 1
fi

clear
echo "========================================================================="
echo "LLsMP V0.1 Alpha for CentOS/RedHat Linux Written by w0w.me"
echo "========================================================================="
echo "A tool to auto-compile & install Litespeed+MySQL+PHP on Linux "
echo ""
echo "For more information please visit http://w0w.me/"
echo "========================================================================="

#set up	email
email="root@localhost.com"
	echo "Please input email:"
	read -p "(Default email: root@localhost.com):" email
	if \[ "$email" = "" \]; then
		email="root@localhost.com"
	fi
	echo "==========================="
	echo email="$email"
	echo "==========================="
	
#set up	username
username="admin"
	echo "Please input username:"
	read -p "(Default username: admin):" username
	if \[ "$username" = "" \]; then
		username="admin"
	fi
	echo "==========================="
	echo username="$username"
	echo "==========================="
	
#set up	password
password="admin123"
	echo "Please input Litespeed and MySQL password(AT LEAST 6 CHARACTERS!!!!!):"
	read -p "(Default password: admin123):" password
	if \[ "$password" = "" \]; then
		password="admin123"
	fi
	echo "==========================="
	echo password="$password"
	echo "==========================="
#check length of password
string=${#password}
	if [ "$string" -lt "6" ]; then
		echo "AT LEAST 6 CHARACTERS!!!!PLEASE RUN THE SCRIPT AGAIN!!!"
		exit 0 
	fi


#Synchronization time
rm -rf /etc/localtime
ln -s /usr/share/zoneinfo/Asia/Shanghai /etc/localtime

yum install -y ntp
ntpdate -d cn.pool.ntp.org
date

#Install packeages
rpm -qa|grep  httpd
rpm -e httpd
rpm -qa|grep mysql
rpm -e mysql
rpm -qa|grep php
rpm -e php
yum -y remove httpd
yum -y remove httpd*
yum -y remove mysql*
yum -y remove php*
yum -y install yum-fastestmirror
yum -y remove httpd
yum -y update
yum -y install gcc automake mhash-devel expect ruby autoconf libtool gcc-c++ libjpeg-devel libpng-devel libxml2-devel curl curl-devel libmcrypt-devel libmcrypt-devel freetype-devel patch make libmcrypt-devel mysql-server mysql-devel zlib-devel

#Download litespeed
mkdir /tmp/llsmp
cd /tmp/llsmp
wget http://llsmp.googlecode.com/files/lsws-4.0.18.tar.gz
tar zxvf lsws-4.0.18.tar.gz
cd lsws-4.0.18
chmod +x functions.sh

#Install Litespeed
expect -c "
spawn /tmp/llsmp/lsws-4.0.18/install.sh
expect \"5RetHEgU10\"
send \"\r\"
expect \"5RetHEgU11\"
send \"$username\r\"
expect \"5RetHEgU12\"
send \"$password\r\"
expect \"5RetHEgU13\"
send \"$password\r\"
expect \"5RetHEgU14\"
send \"$email\r\"
expect \"5RetHEgU1\"
send \"\r\"
expect \"5RetHEgU2\"
send \"\r\"
expect \"5RetHEgU3\"
send \"80\r\"
expect \"5RetHEgU4\"
send \"\r\"
expect \"5RetHEgU5\"
send \"Y\r\"
expect \"5RetHEgU6\"
send \"\r\"
expect \"5RetHEgU7\"
send \"N\r\"
expect \"5RetHEgU8\"
send \"Y\r\"
expect \"5RetHEgU9\"
send \"Y\r\"
"

#Build PHP 
cd /tmp/llsmp
wget http://llsmp.googlecode.com/files/phpbuild.tar.gz
tar zxvf phpbuild.tar.gz
mv -f phpbuild/* /usr/local/lsws/phpbuild
mkdir /tmp/eaccelerator
chmod 777 /tmp/eaccelerator
echo "========================================================================="
echo "INSTALLING PHP"
echo "========================================================================="
/usr/local/lsws/phpbuild/buildphp_manual_run.sh

#Mysql Setting
service mysqld start
mysqladmin -u root password $password
sed -i "2iskip-locking" /etc/my.cnf
sed -i "2iskip-bdb" /etc/my.cnf
sed -i "2iskip-innodb" /etc/my.cnf
service mysqld restart
chkconfig --level 345 mysqld on

#Install Zend Optimizer
wget http://downloads.zend.com/optimizer/3.3.9/ZendOptimizer-3.3.9-linux-glibc23-i386.tar.gz
tar xvf ZendOptimizer-3.3.9-linux-glibc23-i386.tar.gz
cp -f ZendOptimizer-3.3.9-linux-glibc23-i386/data/5_2_x_comp/ZendOptimizer.so /usr/local/lsws/lsphp5/lib/php/extensions/no-debug-non-zts-20060613/
cat >>/usr/local/lsws/lsphp5/lib/php.ini<<EOF
;	 =================
;	 eAccelerator
;	 =================
extension="eaccelerator.so"
eaccelerator.shm_size= 16
eaccelerator.cache_dir="/tmp/eaccelerator"
eaccelerator.enable=1
eaccelerator.optimizer=1
eaccelerator.check_mtime=1
eaccelerator.debug=0
eaccelerator.filter=""
eaccelerator.shm_max="0"
eaccelerator.shm_ttl="0"
eaccelerator.shm_prune_period="0"
eaccelerator.shm_only="0"
eaccelerator.compress="1"
eaccelerator.compress_level="9"

[Zend Optimizer] 
zend_optimizer.optimization_level=1 
zend_extension="ZendOptimizer.so" 
EOF

#Download phpinfo
wget http://llsmp.googlecode.com/files/phpinfo.tar.gz
tar zxvf phpinfo.tar.gz
rm -f /usr/local/lsws/DEFAULT/html/phpinfo.php
mv -f phpinfo.php /usr/local/lsws/DEFAULT/html/

#Download phpmyadmin
wget http://downloads.sourceforge.net/project/phpmyadmin/phpMyAdmin/3.3.9/phpMyAdmin-3.3.9-all-languages.tar.gz
tar zxvf phpMyAdmin-3.3.9-all-languages.tar.gz
mkdir /usr/local/lsws/DEFAULT/html/phpmyadmin
mv -f phpMyAdmin-3.3.9-all-languages/* /usr/local/lsws/DEFAULT/html/phpmyadmin

#Set conf
wget http://llsmp.googlecode.com/files/conf.tar.gz
tar zxvf conf.tar.gz
rm -f /usr/local/lsws/DEFAULT/conf/*
mv conf/* /usr/local/lsws/DEFAULT/conf/

#Restart Litespeed
service lsws restart
echo "========================================================================="
echo "LLsMP has been set up."
echo "Please configure in the Litespeed control panel : http://<your_ip>:7080"
echo "========================================================================="
echo "For more information please visit http://w0w.me/"
echo "========================================================================="
echo "BYE~"
