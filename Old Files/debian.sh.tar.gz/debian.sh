#!/bin/bash

# Check if user is root
if [ $(id -u) != "0" ]; then
    echo "Error: You must be root to run this script, please use root to install lnmp"
    exit 1
fi

clear
echo "========================================================================="
echo "LLsMP V0.2.1 for Debian/Ubuntu ,  Written by w0w.me "
echo "========================================================================="
echo "A tool to auto-compile & install Litespeed+MySQL+PHP on Linux "
echo ""
echo "For more information please visit http://w0w.me/"
echo "========================================================================="

#set up	email
email="root@localhost.com"
	echo "Please input email:"
	read -p "(Default email: root@localhost.com):" email
	if \[ "$email" = "" \]; then
		email="root@localhost.com"
	fi
	echo "==========================="
	echo email="$email"
	echo "==========================="
	
#set up	username
username="admin"
	echo "Please input username:"
	read -p "(Default username: admin):" username
	if \[ "$username" = "" \]; then
		username="admin"
	fi
	echo "==========================="
	echo username="$username"
	echo "==========================="
	
#set up	password
password="admin123"
	echo "Please input Litespeed and MySQL password(AT LEAST 6 CHARACTERS!!!!!):"
	read -p "(Default password: admin123):" password
	if \[ "$password" = "" \]; then
		password="admin123"
	fi
	echo "==========================="
	echo password="$password"
	echo "==========================="
#check length of password
string=${#password}
	if [ "$string" -lt "6" ]; then
		echo "AT LEAST 6 CHARACTERS!!!!PLEASE RUN THE SCRIPT AGAIN!!!"
		exit 0 
	fi


#Synchronization time
rm -rf /etc/localtime
ln -s /usr/share/zoneinfo/Asia/Shanghai /etc/localtime
apt-get update
apt-get install -y ntp chkconfig
ntpdate -d cn.pool.ntp.org
date

#apt-get remove lamp and install software
apt-get install -y apt-spy
cp /etc/apt/sources.list /etc/apt/sources.list.bak
apt-spy update
apt-spy -d stable -a $area -t 5
apt-get update
apt-get remove -y -q apache* 
apt-get remove -y -q mysql* 
apt-get remove -y -q php*
export DEBIAN_FRONTEND=noninteractive
apt-get install -y -q expect libmysql++-dev autoconf gcc g++ libjpeg62-dev libpng12-dev libxml2-dev curl libcurl4-openssl-dev libmcrypt-dev libmhash-dev libfreetype6-dev patch make mcrypt mysql-server libmysql++-dev zlib-bin zlib1g-dev
export PHP_AUTOCONF=/usr/bin/autoconf
export PHP_AUTOHEADER=/usr/bin/autoheader 

mkdir /tmp/llsmp
cd /tmp/llsmp
wget http://llsmp.googlecode.com/files/lsws-4.0.18.tar.gz
tar zxvf lsws-4.0.18.tar.gz
cd lsws-4.0.18
chmod +x functions.sh

#Install Litespeed
expect -c "
spawn /tmp/llsmp/lsws-4.0.18/install.sh
expect \"5RetHEgU10\"
send \"\r\"
expect \"5RetHEgU11\"
send \"$username\r\"
expect \"5RetHEgU12\"
send \"$password\r\"
expect \"5RetHEgU13\"
send \"$password\r\"
expect \"5RetHEgU14\"
send \"$email\r\"
expect \"5RetHEgU1\"
send \"\r\"
expect \"5RetHEgU2\"
send \"\r\"
expect \"5RetHEgU3\"
send \"80\r\"
expect \"5RetHEgU4\"
send \"\r\"
expect \"5RetHEgU5\"
send \"Y\r\"
expect \"5RetHEgU6\"
send \"\r\"
expect \"5RetHEgU7\"
send \"N\r\"
expect \"5RetHEgU8\"
send \"Y\r\"
expect \"5RetHEgU9\"
send \"Y\r\"
"

#Build PHP 
cd /tmp/llsmp
wget http://llsmp.googlecode.com/files/phpbuildv0.2Beta.tar.gz
tar zxvf phpbuildv0.2Beta.tar.gz
mv -f phpbuild/* /usr/local/lsws/phpbuild
mkdir /tmp/eaccelerator
chmod 777 /tmp/eaccelerator

/usr/local/lsws/phpbuild/buildphp_manual_run.sh

#Mysql Setting
/etc/init.d/mysql start
mysqladmin -u root password $password
sed -i "35iskip-locking" /etc/mysql/my.cnf
sed -i "35iskip-bdb" /etc/mysql/my.cnf
sed -i "35iskip-innodb" /etc/mysql/my.cnf
/etc/init.d/mysql restart
update-rc.d mysql defaults

#Install Zend Optimizer
wget http://downloads.zend.com/optimizer/3.3.9/ZendOptimizer-3.3.9-linux-glibc23-i386.tar.gz
tar xvf ZendOptimizer-3.3.9-linux-glibc23-i386.tar.gz
cp -f ZendOptimizer-3.3.9-linux-glibc23-i386/data/5_2_x_comp/ZendOptimizer.so /usr/local/lsws/lsphp5/lib/php/extensions/no-debug-non-zts-20060613/
cat >>/usr/local/lsws/lsphp5/lib/php.ini<<EOF
;        =================
;        eAccelerator
;        =================
extension="eaccelerator.so"
eaccelerator.shm_size= 16
eaccelerator.cache_dir="/tmp/eaccelerator"
eaccelerator.enable=1
eaccelerator.optimizer=1
eaccelerator.check_mtime=1
eaccelerator.debug=0
eaccelerator.filter=""
eaccelerator.shm_max="0"
eaccelerator.shm_ttl="0"
eaccelerator.shm_prune_period="0"
eaccelerator.shm_only="0"
eaccelerator.compress="1"
eaccelerator.compress_level="9"

[Zend Optimizer]
zend_optimizer.optimization_level=1
zend_extension="/usr/local/lsws/lsphp5/lib/php/extensions/no-debug-non-zts-20060613/ZendOptimizer.so"
EOF

#Download phpinfo
wget http://llsmp.googlecode.com/files/phpinfo.tar.gz
tar zxvf phpinfo.tar.gz
rm -f /usr/local/lsws/DEFAULT/html/phpinfo.php
mv -f phpinfo.php /usr/local/lsws/DEFAULT/html/

#Download phpmyadmin
wget http://downloads.sourceforge.net/project/phpmyadmin/phpMyAdmin/3.3.9/phpMyAdmin-3.3.9-all-languages.tar.gz
tar zxvf phpMyAdmin-3.3.9-all-languages.tar.gz
mkdir /usr/local/lsws/DEFAULT/html/phpmyadmin
mv -f phpMyAdmin-3.3.9-all-languages/* /usr/local/lsws/DEFAULT/html/phpmyadmin

#Set conf
wget http://llsmp.googlecode.com/files/conf.tar.gz
tar zxvf conf.tar.gz
rm -f /usr/local/lsws/DEFAULT/conf/*
mv conf/* /usr/local/lsws/DEFAULT/conf/

#Virtual Dir
mkdir /usr/local/lsws/wwwroot
chown -R lsadm:lsadm /usr/local/lsws/wwwroot

#tool
wget http://llsmp.googlecode.com/files/debiantool.tar.gz
tar zxvf debiantool.tar.gz
mkdir /root/llsmp
mv -f vhost.sh /root/llsmp
mv -f vsftpd.sh /root/llsmp

#Restart Litespeed
/etc/init.d/lsws restart
echo "========================================================================="
echo "LLsMP has been set up."
echo "Please configure in the Litespeed control panel : http://<your_ip>:7080"
echo "========================================================================="
echo "For more information please visit http://w0w.me/"
echo "========================================================================="
echo "BYE~"
