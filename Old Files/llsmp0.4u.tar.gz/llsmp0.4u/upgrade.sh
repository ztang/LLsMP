#!/bin/bash

clear
echo "========================================================================="
echo "LLsMP V0.3 upgrade to 0.4 for CentOS/RedHat Linux Written by w0w.me"
echo "========================================================================="
echo "A tool to auto-compile & install Litespeed+MySQL+PHP on Linux "
echo ""
echo "For more information please visit http://llsmp.org/"
echo "========================================================================="

# Check if user is root
if [ $(id -u) != "0" ]; then
    echo "Error: You must be root to run this script, please use root to install llsmp"
    exit 1
fi

cd `dirname "$0"`
source ./functions.sh 2>/dev/null
if [ $? != 0 ]; then
    . ./functions.sh
    if [ $? != 0 ]; then
        echo [ERROR] Can not include 'functions.sh'.
        exit 1
    fi
fi
HOME=$(pwd)

check_installed

if [ $INSATLL_TYPE = "upgrade" ];then
init

if [ $php_i = "y" ] && [ $mysql_i = "y" ]; then
mv /usr/local/lsws/lsphp5/lib/php.ini /usr/local/lsws/lsphp5/lib/php.ini.bak
build_php
fi

if [ $php_i = "y" ] && [ $mysql_i != "y" ]; then
mv /usr/local/lsws/lsphp5/lib/php.ini /usr/local/lsws/lsphp5/lib/php.ini.bak
build_php_without_mysql
fi


if [ $ea_i = "y" ];then
sh $HOME/tool/eaccelerator.sh
fi

if [ $zend_i = "y" ];then
sh $HOME/tool/zend_optimizer.sh
fi

if [ $ioncube_i = "y" ];then
sh $HOME/tool/ioncube.sh
fi

tool
/etc/init.d/lsws restart
finish

fi
