#!/bin/bash

check_installed()
{
version=$(cat /root/llsmp/.installed)
if [ "$version" = "LLsMP 0.3 CentOS" ];then
INSATLL_TYPE="upgrade"
else
echo "LLsMP 0.3 Centos have not been installed"
exit 1
fi
}

init()
{
#check mysql
if [ $(which mysql) = '/usr/bin/mysql' ];then
mysql_i="y"
fi

echo "========================================================================="
printf "Do you want to upgrade php to version 5.2.17?(y/n)"
read php_i
if [ $php_i = "y" ]; then
echo "You have chosen to upgrade php."
echo "WARNING!!!php.ini will be erased!!!!"
echo "========================================================================="
printf "Do you want to downagrade eAccelerator to version 0.8.5.3?(y/n)"
read ea_i
printf "Do you want to install Zend Optimizer?(y/n)"
read zend_i
printf "Do you want to install ionCube Loader?(y/n)"
read ioncube_i
echo "========================================================================="
echo ""
else
echo "There is nothing can be upgraded."
fi
}

build_php()
{
#Build PHP 
mkdir /usr/local/lsws/phpbuild
cd /tmp/llsmp
wget http://us.php.net/get/php-5.2.17.tar.gz/from/this/mirror -O php-5.2.17.tar.gz
wget http://www.litespeedtech.com/packages/lsapi/php-litespeed-5.5.tgz
wget http://files.directadmin.com/services/custombuild/php-5.2.17-mail-header.patch
tar zxvf php-5.2.17.tar.gz
tar zxvf php-litespeed-5.5.tgz
cd /tmp/llsmp/php-5.2.17
patch -p1 < /tmp/llsmp/php-5.2.17-mail-header.patch
mv /tmp/llsmp/litespeed /tmp/llsmp/php-5.2.17/sapi/litespeed/
cd /tmp/llsmp
mv php-5.2.17 /usr/local/lsws/phpbuild
cd /usr/local/lsws/phpbuild/php-5.2.17
touch ac*
rm -rf autom4te.*
./buildconf --force
./configure '--prefix=/usr/local/lsws/lsphp5' '--with-pdo-mysql' '--with-mysql' '--with-mysqli' '--with-zlib' '--with-gd' '--enable-shmop' '--enable-track-vars' '--enable-sockets' '--enable-sysvsem' '--enable-sysvshm' '--enable-magic-quotes' '--enable-mbstring' '--with-iconv' '--with-litespeed' '--enable-inline-optimization' '--with-curl' '--with-curlwrappers' '--with-mcrypt' '--with-mhash' '--with-mime-magic' '--with-openssl' '--with-freetype-dir=/usr/lib' '--with-jpeg-dir=/usr/lib'
make clean
echo `date`
make
make -k install
cd /usr/local/lsws/fcgi-bin
if [ -e "lsphp-5.2.17" ] ; then
	mv lsphp-5.2.17 lsphp-5.2.17.bak
fi
cp /usr/local/lsws/phpbuild/php-5.2.17/sapi/litespeed/php lsphp-5.2.17
ln -sf lsphp-5.2.17 lsphp5
chown -R lsadm:lsadm /usr/local/lsws/phpbuild/php-5.2.17
echo "[zend]" >>/usr/local/lsws/lsphp5/lib/php.ini
}


build_php_without_mysql()
{
#Build PHP 
mkdir /usr/local/lsws/phpbuild
cd /tmp/llsmp
wget http://us.php.net/get/php-5.2.17.tar.gz/from/this/mirror -O php-5.2.17.tar.gz
wget http://www.litespeedtech.com/packages/lsapi/php-litespeed-5.5.tgz
wget http://files.directadmin.com/services/custombuild/php-5.2.17-mail-header.patch
tar zxvf php-5.2.17.tar.gz
tar zxvf php-litespeed-5.5.tgz
cd /tmp/llsmp/php-5.2.17
patch -p1 < /tmp/llsmp/php-5.2.17-mail-header.patch
mv /tmp/llsmp/litespeed /tmp/llsmp/php-5.2.17/sapi/litespeed/
cd /tmp/llsmp
mv php-5.2.17 /usr/local/lsws/phpbuild
cd /usr/local/lsws/phpbuild/php-5.2.17
touch ac*
rm -rf autom4te.*
./buildconf --force
./configure '--prefix=/usr/local/lsws/lsphp5' '--with-zlib' '--with-gd' '--enable-shmop' '--enable-track-vars' '--enable-sockets' '--enable-sysvsem' '--enable-sysvshm' '--enable-magic-quotes' '--enable-mbstring' '--with-iconv' '--with-litespeed' '--enable-inline-optimization' '--with-curl' '--with-curlwrappers' '--with-mcrypt' '--with-mhash' '--with-mime-magic' '--with-openssl' '--with-freetype-dir=/usr/lib' '--with-jpeg-dir=/usr/lib'
make clean
echo `date`
make
make -k install
cd /usr/local/lsws/fcgi-bin
if [ -e "lsphp-5.2.17" ] ; then
	mv lsphp-5.2.17 lsphp-5.2.17.bak
fi
cp /usr/local/lsws/phpbuild/php-5.2.17/sapi/litespeed/php lsphp-5.2.17
ln -sf lsphp-5.2.17 lsphp5
chown -R lsadm:lsadm /usr/local/lsws/phpbuild/php-5.2.17
echo "[zend]" >>/usr/local/lsws/lsphp5/lib/php.ini
}

tool()
{
rm -rf /root/llsmp
mkdir /root/llsmp
cp tool/* /root/llsmp
echo "LLsMP 0.4 CentOS" >> /root/llsmp/.installed
}

finish()
{
echo "========================================================================="
echo "LLsMP has been upgraded."
echo "Please configure in the Litespeed control panel : http://<your_ip>:7080"
echo "========================================================================="
echo "For more information please visit http://llsmp.org/"
echo "========================================================================="
echo "BYE~"
}